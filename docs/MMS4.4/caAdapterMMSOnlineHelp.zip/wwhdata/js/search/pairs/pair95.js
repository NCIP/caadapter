function FileData_Pairs(x)
{
x.t("cabig","cabig");
x.t("cabig","material");
x.t("cabig","compatibility");
x.t("references","cabig");
x.t("material","references");
x.t("material","cabig");
x.t("compatibility","guidelines");
}
