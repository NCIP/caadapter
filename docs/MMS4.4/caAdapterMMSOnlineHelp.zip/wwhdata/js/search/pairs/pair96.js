function FileData_Pairs(x)
{
x.t("references","cacore");
x.t("cacore","cabio");
x.t("cacore","material");
x.t("cabio","cadsr");
x.t("material","references");
x.t("material","cacore");
x.t("material","nci");
x.t("cbiit","cacore");
x.t("nci","cbiit");
}
