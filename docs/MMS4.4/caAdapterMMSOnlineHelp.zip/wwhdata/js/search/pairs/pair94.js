function FileData_Pairs(x)
{
x.t("references","articles");
x.t("articles","references");
x.t("articles","articles");
x.t("articles","java");
x.t("metadata","interchange");
x.t("extensible","markup");
x.t("language",":xml");
x.t("java","programming");
x.t("programming","extensible");
x.t(":xml","metadata");
x.t("markup","language");
}
