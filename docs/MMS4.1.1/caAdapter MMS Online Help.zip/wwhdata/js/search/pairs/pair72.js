function FileData_Pairs(x)
{
x.t("cadsr","http://ncicb.nci.nih.gov/ncicb/infrastructure/cacore_overview/cadsr");
x.t("https://cabig.nci.nih.gov/tools/cacore_sdk","cabio");
x.t("references","cacore");
x.t("http://ncicb.nci.nih.gov","cacore");
x.t("cacore","https://cabig.nci.nih.gov/tools/cacore_sdk");
x.t("cacore","material");
x.t("cabio","https://wiki.nci.nih.gov/display/icr/cabio");
x.t("https://wiki.nci.nih.gov/display/icr/cabio","cadsr");
x.t("material","references");
x.t("material","cacore");
x.t("material","nci");
x.t("cbiit","http://ncicb.nci.nih.gov");
x.t("nci","cbiit");
}
