function FileData_Pairs(x)
{
x.t("references","articles");
x.t("articles","references");
x.t("articles","articles");
x.t("articles","java");
x.t("metadata","interchange");
x.t("extensible","markup");
x.t("language","http://www.w3.org/tr/rec-xml/");
x.t("xml","metadata");
x.t("interchange","http://www.omg.org/technology/documents/formal/xmi.htm");
x.t("java","programming");
x.t("http://java.sun.com/learning/new2java/index.html","extensible");
x.t("programming","http://java.sun.com/learning/new2java/index.html");
x.t("http://www.w3.org/tr/rec-xml/","xml");
x.t("markup","language");
}
