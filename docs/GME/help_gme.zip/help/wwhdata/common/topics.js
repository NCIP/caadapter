function  WWHBookData_MatchTopic(P)
{
var C=null;
if(P=="Welcome")C="caAdapter%20GME%20Welcome.1.1.html#1064689";
return C;
}
