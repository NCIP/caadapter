function  WWHBookData_Files(P)
{
P.fA("Welcome to caAdapter Online Help","caAdapter%20GME%20Welcome.1.1.html");
P.fA("Using caAdapter Online Help","caAdapter%20GME%20Welcome.1.2.html");
P.fA("Using the GME Module","caAdapter%20GME%204.2%20Using%20the%20GME%20Module.2.1.html");
P.fA("Introduction to caAdapter","caAdapter%20GME%204.2%20Using%20the%20GME%20Module.2.2.html");
P.fA("Create an XSD Meta to XMI Model Mapping File","caAdapter%20GME%204.2%20Using%20the%20GME%20Module.2.3.html");
P.fA("Mapping Rules","caAdapter%20GME%204.2%20Using%20the%20GME%20Module.2.4.html");
P.fA("caAdapter GME Glossary","caAdapter%20GME%204.2%20Glossary.3.1.html");
}
