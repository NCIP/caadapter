function  WWHBookData_AddIndexEntries(P)
{
var A=P.fA("G",null,null,"002");
var B=A.fA("GME",new Array("2#1073155","3#1073168","4#1073256","4#1073261","4#1073265","5#1074251","6#1090621","6#1090655"));
B=A.fA("GME Tags",new Array("4#1073256"));
A=P.fA("M",null,null,"002");
B=A.fA("Mapping Tool",new Array("4#1073215","4#1073225","4#1073235","4#1073245","4#1073246","4#1073265"));
A=P.fA("N",null,null,"002");
B=A.fA("NCI CBIIT",new Array("6#1090626"));
A=P.fA("O",null,null,"002");
B=A.fA("Online help");
var C=B.fA("locating topics of interest",new Array("1#1065946"));
C=B.fA("printing",new Array("1#1065966"));
C=B.fA("using navigation tools",new Array("1#1065957"));
B=A.fA("Online help, using",new Array("1"));
A=P.fA("U",null,null,"002");
B=A.fA("UML",new Array("6#1090618","6#1090631","6#1090652"));
B=A.fA("Using online help",new Array("1"));
A=P.fA("X",null,null,"002");
B=A.fA("XMI",new Array("4","4#1073181","4#1073192","4#1073196","4#1074790","4#1073225","4#1073232","4#1073235","4#1073245","4#1073255","4#1073256","4#1073261","4#1073265","5#1073649","5#1073276","5#1073279","5#1073282","6#1090636"));
B=A.fA("XSD",new Array("3#1073168","4","4#1073181","4#1073192","4#1073196","4#1074790","4#1074952","4#1074962","4#1073215","4#1073223","4#1073235","4#1073245","4#1073255","5#1073649","5#1073276","5#1073279","5#1073282","6#1090645"));
}

function  WWHBookData_MaxIndexLevel()
{
  return 3;
}
