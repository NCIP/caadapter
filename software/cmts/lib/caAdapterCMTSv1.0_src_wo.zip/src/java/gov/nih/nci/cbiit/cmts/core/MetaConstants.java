package gov.nih.nci.cbiit.cmts.core;

public interface MetaConstants {
	public static int SCHEMA_LAZY_LOADINTG_INITIAL=5;
	public static int SCHEMA_LAZY_LOADINTG_INCREMENTAL=3;

}
