function FileData_Pairs(x)
{
x.t("available","caadapter");
x.t("references","available");
x.t("references","references");
x.t("references","following");
x.t("cabig","material");
x.t("articles","cabig");
x.t("cacore","material");
x.t("software","products");
x.t("types","references");
x.t("material","cacore");
x.t("material","software");
x.t("caadapter","articles");
x.t("following","types");
}
