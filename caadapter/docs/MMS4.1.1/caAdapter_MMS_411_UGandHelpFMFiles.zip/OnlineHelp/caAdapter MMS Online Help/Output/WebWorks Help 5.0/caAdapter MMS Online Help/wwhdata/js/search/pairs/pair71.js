function FileData_Pairs(x)
{
x.t("http://cabig.nci.nih.gov/","cabig");
x.t("guidelines","http://cabig.nci.nih.gov/guidelines_documentation");
x.t("cabig","http://cabig.nci.nih.gov/");
x.t("cabig","material");
x.t("cabig","compatibility");
x.t("references","cabig");
x.t("material","references");
x.t("material","cabig");
x.t("compatibility","guidelines");
}
