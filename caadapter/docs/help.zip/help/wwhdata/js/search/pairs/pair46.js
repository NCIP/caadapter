function FileData_Pairs(x)
{
x.t("http://ncicb.nci.nih.gov/core/cabio","cadsr");
x.t("cadsr","http://ncicb.nci.nih.gov/core/cadsr");
x.t("references","cacore");
x.t("http://ncicb.nci.nih.gov","cacore");
x.t("cacore","material");
x.t("cacore","http://ncicb.nci.nih.gov/core");
x.t("cabio","http://ncicb.nci.nih.gov/core/cabio");
x.t("material","references");
x.t("material","cacore");
x.t("material","nci");
x.t("cbiit","http://ncicb.nci.nih.gov");
x.t("nci","cbiit");
x.t("http://ncicb.nci.nih.gov/core","cabio");
}
