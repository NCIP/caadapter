// Copyright (c) 2000-2003 Quadralay Corporation.  All rights reserved.
//

// Search complete
//
WWHFrame.WWHSearch.fSearchWordsComplete();
