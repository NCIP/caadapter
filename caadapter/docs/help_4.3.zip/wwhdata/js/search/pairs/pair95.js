function FileData_Pairs(x)
{
x.t("describes","different");
x.t("provided","caadapter");
x.t("functions","provided");
x.t("functions","mapping");
x.t("function","specifications");
x.t("different","functions");
x.t("section","describes");
x.t("section","include");
x.t("include","functions");
x.t("caadapter","function");
x.t("caadapter","topics");
x.t("topics","section");
x.t("mapping","section");
x.t("mapping","using");
x.t("using","functions");
}
