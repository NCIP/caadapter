function FileData_Pairs(x)
{
x.t("instructions","installing");
x.t("installing","caadapter");
x.t("complete","instructions");
x.t("guide","http://ncicb.nci.nih.gov/ncicb/infrastructure/cacore_overview/caadapter/");
x.t("overview","resources");
x.t("located","caadapter");
x.t("caadapter","complete");
x.t("caadapter","overview");
x.t("caadapter","located");
x.t("caadapter","caadapter");
x.t("caadapter","installation");
x.t("caadapter","resources");
x.t("installation","guide");
x.t("resources","installing");
}
