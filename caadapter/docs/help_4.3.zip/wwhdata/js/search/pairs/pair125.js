function FileData_Pairs(x)
{
x.t("cadsr","http://ncicb.nci.nih.gov/ncicb/infrastructure/cacore_overview/cadsr");
x.t("jsessionid=05c3565fb5ddb15ed00f27ef057d1a15","cadsr");
x.t("http://ncicb.nci.nih.gov/ncicb/infrastructure","cabio");
x.t("references","cacore");
x.t("http://ncicb.nci.nih.gov","cacore");
x.t("cacore","http://ncicb.nci.nih.gov/ncicb/infrastructure");
x.t("cacore","material");
x.t("cabio","jsessionid=05c3565fb5ddb15ed00f27ef057d1a15");
x.t("cabio","https://wiki.nci.nih.gov/display/icr/");
x.t("material","references");
x.t("material","cacore");
x.t("material","cbiit");
x.t("cbiit","http://ncicb.nci.nih.gov");
x.t("https://wiki.nci.nih.gov/display/icr/","cabio");
}
