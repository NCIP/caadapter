function FileData_Pairs(x)
{
x.t("ant","http://ant.apache.org/");
x.t("products","references");
x.t("products","software");
x.t("products","java");
x.t("references","software");
x.t("software","products");
x.t("java","http://java.sun.com");
x.t("http://java.sun.com","ant");
}
