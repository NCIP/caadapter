// Copyright (c) 2001-2003 Quadralay Corporation.  All rights reserved.
//

document.writeln("<title>caAdapter 4.3 Online Help</title>");
